import React from 'react'

let Header = () => {
  return (<div className="header">
        <h1>Todos List</h1>
    </div>)
}

export default Header;